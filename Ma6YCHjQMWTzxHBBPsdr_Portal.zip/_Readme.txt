Thank you for using our freebies and products. We hope it'll help you to create something incredible!

Free fonts used in design:
• Karla https://fonts.google.com/specimen/Karla

---

We're Nice, Very Nice! 
Check out more products: https://niceverynice.com/